package com.cg.mobilebilling.daoservices;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.mobilebilling.beans.PostpaidAccount;
@Qualifier("JpaRepository")
public interface PostpaidAccountDAOServices extends JpaRepository<PostpaidAccount, Long>{
	@Query(value="UPDATE PostpaidAccount SET planID=3? WHERE mobileNo=2?", nativeQuery=true)
	boolean changePlan(int customerID, long mobileNo, int planID);
}
